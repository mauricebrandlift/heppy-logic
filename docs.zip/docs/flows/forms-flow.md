# Basisflow Formulieren

Dit document beschrijft stap voor stap hoe nieuwe formulieren en multi-step flows opgezet worden. Gebruik de bijbehorende templates in `docs/jsFileTemplates/` om snel te starten:

* **pageJS.js** (flow-orchestrator)
* **formJS.js** (form-module)
* **apiJS.js** (API-wrappers)
* **formSchemaJS.js** (veld- & form-schema)
* **formInputSanitizerJS.js** (input sanitization)

---

## 1. Splide Initialisatie (Webflow)

In je Webflow-pagina voeg je de Splide-script-tag toe (één keer per site) in de `<head>` of vlak voor `</body>`:

```html
<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@latest/dist/js/splide.min.js"></script>
<script>
  let splide;
  document.addEventListener("DOMContentLoaded", function () {
    splide = new Splide(".splide", {
      type: "fade",
      drag: false,
      arrows: false,
      pagination: false
    }).mount();

    // Vorige stap-knoppen
    document.querySelectorAll('[buttonType="prev"]').forEach(btn => {
      btn.addEventListener("click", () => splide.go("-1"));
    });

    // Wird vanuit form-modules aangeroepen
    window.moveToNextSlide = function () {
      if (splide) splide.go("+1");
      else console.error("Splide niet geïnitialiseerd");
    };
  });
</script>
```

> **Tip**: de `moveToNextSlide()` functie kun je in je form-module submit-handler aanroepen zodra een stap voltooid is.

---

## 2. Flow-Orchestrator: `public/pages/<flowName>Page.js`

In de map `public/pages/` staan voor elke multi-step flow één pagina-script. Dit is de centrale orchestrator:

```js
// public/pages/aanvraagPage.js
import { initAddressStep } from '../forms/aanvraag/addressForm.js';
import { initScheduleStep } from '../forms/aanvraag/scheduleForm.js';
// ... andere stappen

document.addEventListener('DOMContentLoaded', () => {
  initAddressStep();
});

document.addEventListener('address:completed', () => initScheduleStep());
// ... luister op '<stepName>:completed' events
```

**Zie template:** `docs/jsFileTemplates/pageJS.js`

---

## 3. Form-modules: `public/forms/<submap>/<stepName>Form.js`

Elke stap krijgt een eigen module in een submap (bijv. `aanvraag` of `adres`):

```js
// public/forms/aanvraag/addressForm.js
import { formSchemas } from '../../forms/schemas/formSchema.js';
import { initAddressStep } from '../../../docs/jsFileTemplates/formJS.js';

export function initAddressStep() {
  initAddressStep({ formName: 'checkAdres', schema: formSchemas.checkAdres });
}
```

* **`data-form-name="checkAdres"`** op het `<form>`-element
* **`data-field-name`** op alle `<input>`-velden
* **`data-form-button="checkAdres"`** op de submit-button

**Zie template:** `docs/jsFileTemplates/formJS.js`

---

## 4. Core Logica & Helpers

### 4.1 Sanitization & Storage

* **`public/forms/logic/formInputSanitizer.js`**: alle inputs `trim()` en basis-escape.
* **`public/forms/logic/formStorage.js`**: `save(key, data)` en `load(key)` in `localStorage`.

**Zie template:** `docs/jsFileTemplates/formInputSanitizerJS.js`

### 4.2 Schema- & Validator-engine

* **`public/forms/schemas/formSchema.js`**: alle `validationGroups` en `formSchemas`.
* **`public/forms/validators/formValidator.js`**: map met `validateXxx`-functies + `validateField`, `validateForm`, `validateFull`.

**Zie templates:** `docs/jsFileTemplates/formSchemaJS.js`, `docs/jsFileTemplates/formValidatorJS.js`, en `docs/jsFileTemplates/formJS.js`

### 4.3 UI-helpers

* **`public/forms/ui/formUI.js`**: tonen/verbergen errors, spinners, button toggles, redirects.

---

## 5. Utils

* **`public/utils/api.js`**: alle API-calls (checkAdres, coverageCheck, createOrder, etc.).
* **`public/utils/stripe.js`**: initialisatie en checkout-logica.

**Zie template:** `docs/jsFileTemplates/apiJS.js`

---

# Samenvatting: Nieuwe Formulier-Stap

1. **Schema**: voeg entry toe aan `formSchema.js` (of `validationGroups`).
2. **API**: indien nodig, schrijf wrapper in `utils/api.js`.
3. **HTML**: `<form data-form-name="<formName>">`, `<input data-field-name>`, `<button data-form-button>`.
4. **Form-module**: kopieer `formJS.js` template, pas `formName` en import path aan.
5. **Flow**: koppel in `public/pages/<flowName>Page.js` een listener op `<formName>:completed`.
6. **Splide**: roep `moveToNextSlide()` aan in je submit-handler.

Met deze structuur kan ChatGPT of Copilot in **één oogopslag** zien hoe nieuwe formulieren en stappen worden toegevoegd en waar alle logica zich bevindt.
