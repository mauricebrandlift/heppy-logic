/**
 * formValidator.js
 *
 * Dit bestand bevat alle validator-functies en de logica om velden en volledige formulieren te valideren.
 *
 * 1. Voeg nieuwe validator-functies toe in de `validators` map.
 * 2. Gebruik in formSchema.js de naam van de validator om die functie te draaien.
 *
 * Beschikbare functies:
 * - validateField(schemaFields, fieldName, value)
 * - validateForm(schemaFields, formEl)
 * - validateFull(schemaFields, data, api)
 */

// 1) Validator-functies: voeg hier nieuwe validatie-routines toe
export const validators = {
  // Voorbeeld validatie voor postcode
  validatePostcode(value) {
    const regex = /^[1-9][0-9]{3}\s?[A-Za-z]{2}$/;
    return regex.test(value)
      ? []
      : ['validatePostcode'];
  },

  // Voorbeeld validatie voor huisnummer (1-4 cijfers)
  validateHuisnummer(value) {
    return /^\d{1,4}$/.test(value)
      ? []
      : ['validateHuisnummer'];
  },

  // Voorbeeld validatie van toevoeging (max 3 alfanumerieke)
  validateToevoeging(value) {
    return /^[A-Za-z0-9]{0,3}$/.test(value)
      ? []
      : ['validateToevoeging'];
  },

  // Voeg hier je eigen validateVoornaam, validateAchternaam, etc. toe
};

/**
 * Valideer één veld volgens het schema
 * @param {object} schemaFields - velddefinities uit formSchema
 * @param {string} fieldName - naam van het veld
 * @param {any} value - waarde om te valideren
 * @returns {string[]} array van fout-keys (lege array als ok)
 */
export function validateField(schemaFields, fieldName, value) {
  const fieldConfig = schemaFields[fieldName];
  if (!fieldConfig || !fieldConfig.validators) return [];

  let errors = [];
  fieldConfig.validators.forEach(fnName => {
    const fn = validators[fnName];
    if (typeof fn === 'function') {
      const result = fn(value);
      if (Array.isArray(result) && result.length) {
        errors = errors.concat(result);
      }
    }
  });
  return errors;
}

/**
 * Snel check of alle velden in het formEl valide zijn
 * @param {object} schemaFields
 * @param {HTMLElement} formEl
 * @returns {boolean} true als alle velden geen fouten bevatten
 */
export function validateForm(schemaFields, formEl) {
  let valid = true;
  Object.keys(schemaFields).forEach(name => {
    const input = formEl.querySelector(`[data-field-name="${name}"]`);
    if (!input) return;
    const errors = validateField(schemaFields, name, input.value);
    if (errors.length) valid = false;
  });
  return valid;
}

/**
 * Volledige validatie inclusief mogelijke async checks (bijv. API-calls)
 * @param {object} schemaFields
 * @param {object} data - verzamelde form-waarden
 * @param {object} api - object met async validator-wrappers (postcodeCheck, coverageCheck)
 * @returns {Promise<string[]>} array van alle fout-keys
 */
export async function validateFull(schemaFields, data, api) {
  let allErrors = [];

  // 1) Sync validatie per veld
  for (const [name, value] of Object.entries(data)) {
    const fieldErrors = validateField(schemaFields, name, value);
    if (fieldErrors.length) allErrors = allErrors.concat(fieldErrors);
  }

  // 2) Async validaties (optioneel)
  // Bijvoorbeeld: postcode-check via API
  if (schemaFields.postcode && data.postcode && data.huisnummer) {
    try {
      const res = await api.postcodeCheck(data);
      if (!res.exists) allErrors.push('addressNotFound');
    } catch (err) {
      allErrors.push('addressCheckError');
    }
  }

  return allErrors;
}
