/**
 * api.js
 *
 * Centrale plek voor alle API-wrappers in het project.
 * Hier definieer je functies om te communiceren met externe en interne endpoints.
 *
 * Workflow:
 * 1. Voeg een nieuwe functie toe die een HTTP-call maakt.
 * 2. Exporteer de functie onder een duidelijke naam, bijv. `checkAdres`, `getAvailableCleaners`.
 * 3. Importeer en gebruik in form-modules of page-modules via:
 *      import * as api from '../utils/api.js';
 *
 * Voor interne API-endpoints gebruik je het `/api`-pad van je Next.js/Vercel Functions/app.
 * Voor externe: base-url config in environment variables (bijv. POSTCODE_API_URL).
 */

import { getEnv } from './config.js'; // helper om env variabelen te lezen

const BASE_INTERNAL = '/api';
const BASE_POSTCODE = getEnv('POSTCODE_API_URL'); // bijv. https://api.postcodeapi.nu/v2

/**
 * Voorbeeld: check of een Nederlands adres bestaat via externe PostcodeAPI
 * @param {object} data - { postcode: string, huisnummer: string }
 * @returns {Promise<{ exists: boolean, payload?: object }>} 
 */
export async function checkAdres(data) {
  const url = `${BASE_POSTCODE}/addresses/?postcode=${encodeURIComponent(data.postcode)}&number=${encodeURIComponent(data.huisnummer)}`;
  try {
    const res = await fetch(url, {
      headers: { 'X-Api-Key': getEnv('POSTCODE_API_KEY') }
    });
    if (res.ok) {
      const json = await res.json();
      return { exists: true, payload: json }; // payload bevat adres-details
    }
    if (res.status === 404) {
      return { exists: false };
    }
    throw new Error(`Unexpected status ${res.status}`);
  } catch (err) {
    console.error('checkAdres error', err);
    throw err;
  }
}

/**
 * Voorbeeld: interne endpoint om te checken of een postcode+huisnummer binnen dekking valt
 * @param {object} data - { postcode: string, huisnummer: string }
 * @returns {Promise<{ coverage: boolean }>}
 */
export async function coverageCheck(data) {
  const url = `${BASE_INTERNAL}/coverage?postcode=${encodeURIComponent(data.postcode)}&number=${encodeURIComponent(data.huisnummer)}`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`coverageCheck failed: ${res.status}`);
  }
  return res.json(); // { coverage: boolean }
}

/**
 * Voorbeeld: POST request aan interne endpoint voor het aanmaken van een bestelling
 * @param {object} payload - alle nodige data voor de bestelling
 * @returns {Promise<object>} response JSON
 */
export async function createOrder(payload) {
  const url = `${BASE_INTERNAL}/orders`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || 'createOrder failed');
  }
  return res.json();
}

/**
 * Nieuwe API-wrappers toevoegen:
 *
 * export async function myNewEndpoint(data) {
 *   const url = `${BASE_INTERNAL}/my-endpoint?param=${encodeURIComponent(data.param)}`;
 *   const res = await fetch(url);
 *   if (!res.ok) throw new Error(...);
 *   return res.json();
 * }
 */
