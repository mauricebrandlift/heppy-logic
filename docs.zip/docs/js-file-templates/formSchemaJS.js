/**
 * formSchema.js
 *
 * Centrale registratie van alle validatie-groepen en formulier-schemas.
 *
 * - validationGroups: herbruikbare sets van velddefinities en validatie-regels
 * - formSchemas: concrete formulier-stappen die verwijzen naar een validationGroup
 *
 * Workflow:
 * 1. Voeg nieuwe validationGroup toe in "validationGroups".
 * 2. Voeg nieuwe formSchema toe in "formSchemas", met een verwijzing naar een validationGroup of inline definitie.
 * 3. (Optioneel) Specificeer een 'group' binnen de validationGroup voor shared storage tussen formulieren.
 */

// 1) Herbruikbare validatie-groepen
export const validationGroups = {
  adresSchema: {
    group: 'address',
    fields: {
      postcode:   { validators: ['validatePostcode'] },
      huisnummer: { validators: ['validateHuisnummer'] },
      toevoeging: { validators: ['validateToevoeging'] }
    }
  },

  algemeneGegevens: {
    group: 'personal',
    fields: {
      voornaam:   { validators: ['validateVoornaam'] },
      achternaam: { validators: ['validateAchternaam'] },
      email:      { validators: ['validateEmail'] }
    }
  },

  aanvraagDagdeel: {
    fields: {
      datum:      { validators: ['validateDatum'] },
      tijdvak:    { validators: ['validateTijdvak'] }
    }
  }
};

// 2) Concrete formulier-schemas
export const formSchemas = {
  // Adres check-formulier gebruikt de adresSchema
  checkAdres: validationGroups.adresSchema,

  // Dagdeel-keuze stap in aanvraag-flow
  'aanvraag-dagdeel': validationGroups.aanvraagDagdeel,

  // Persoonsgegevens stap gebruikt de algemeneGegevens group
  'persoonlijke-gegevens': validationGroups.algemeneGegevens,

  // Inline schema voor abonnementsdetails (optioneel)
  subscriptionDetails: {
    group: 'subscription',
    fields: {
      type:     { validators: ['validateSubscriptionType'] },
      interval: { validators: ['validateSubscriptionInterval'] }
    }
  }
};

/**
 * Voorbeeld: nieuwe validationGroup toevoegen
 * 
 * validationGroups['betaalSchema'] = {
 *   group: 'payment',
 *   fields: {
 *     cardNumber: { validators: ['validateCreditCard'] },
 *     expiry:     { validators: ['validateExpiryDate'] }
 *   }
 * };
 *
 * Voorbeeld: nieuw formSchema toevoegen
 * 
 * formSchemas['checkout-payment'] = validationGroups.betaalSchema;
 */
