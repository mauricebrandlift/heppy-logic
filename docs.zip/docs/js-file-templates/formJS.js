/**
 * Sjabloon: <flowName><stepName>Form.js
 *
 * Module voor één stap in een multi-step formulier.
 * Gebruik custom attributen voor selectie:
 *   - Formulier: <form data-form-name="<flowName>-<stepName>">
 *   - Velden:   <input data-field-name="<fieldName>">
 *   - Knop:     <button data-form-button="<flowName>-<stepName>">
 *
 * Dit sjabloon ondersteunt "groups" voor gedeelde data, bijvoorbeeld adresgegevens.
 * Geef in formSchema.js per formulier/stap optioneel een `group` op.
 */

// 1) IMPORTS\ nimport { formSchemas } from '../schemas/formSchema.js';
import { validateField, validateForm, validateFull } from '../validators/formValidator.js';
import { sanitize, collect } from '../logic/formInputSanitizer.js';
import { save, load } from '../logic/formStorage.js';
import * as ui from '../ui/formUI.js';
import * as api from '../../../utils/api.js';

// 2) CONSTANTEN EN SELECTORS
const FORM_NAME = '<flowName>-<stepName>';  // waarde voor data-form-name en data-form-button
const formEl = document.querySelector(`[data-form-name="${FORM_NAME}"]`);
const submitBtn = document.querySelector(`[data-form-button="${FORM_NAME}"]`);

// Definieer schema: velden en optionele group (bijv. 'address')
const { fields: schemaFields = {}, group: schemaGroup } = formSchemas[FORM_NAME] || {};

// 3) INIT-FUNCTIE
/**
 * Initialiseert de formulierstap:
 * - Prefill uit localStorage
 * - Eventlisteners op inputs
 * - Submit-handler
 * - Init status van de knop
 */
export function initStepNameForm() {
  if (!formEl) return;

  // 3a) Prefill: laad gedeelde data (group) of specifieke form-data
  const storageKey = schemaGroup || FORM_NAME;
  const saved = load(storageKey) || {};
  if (Object.keys(saved).length) {
    const toPrefill = {};
    Object.keys(schemaFields).forEach(name => {
      if (saved[name] != null) toPrefill[name] = saved[name];
    });
    ui.prefillFields(formEl, toPrefill);
    const isValid = validateForm(schemaFields, formEl);
    ui.toggleButton(submitBtn, isValid);
  }

  // 3b) Input events: sanitizen, veldvalidatie en knopstatus
  formEl.querySelectorAll('[data-field-name]').forEach(input => {
    const fieldName = input.getAttribute('data-field-name');
    input.addEventListener('input', () => {
      const raw = input.value;
      const clean = sanitize(raw);
      input.value = clean;

      // valideer dit veld aan de hand van het schema
      const fieldErrors = validateField(schemaFields, fieldName, clean);
      ui.showErrors(formEl, fieldName, fieldErrors);

      // valideer het hele formulier en update knop
      const formValid = validateForm(schemaFields, formEl);
      ui.toggleButton(submitBtn, formValid);
    });
  });

  // 3c) Submit event: volledige validatie, opslaan, API-call en event dispatch
  formEl.addEventListener('submit', async event => {
    event.preventDefault();
    ui.showLoader(submitBtn);
    ui.toggleFields(formEl, false);

    const data = collect(formEl);
    const errors = await validateFull(schemaFields, data, api);
    if (errors.length) {
      ui.showErrors(formEl, errors);
      ui.hideLoader(submitBtn);
      ui.toggleFields(formEl, true);
      return;
    }

    // sla de gegevens op onder groep of eigen formuliernaam
    const existing = load(storageKey) || {};
    save(storageKey, { ...existing, ...data });

    // tijdelijke placeholder voor API-call
    const result = await api[`${FORM_NAME}Check`]?.(data) ?? { success: true, detail: data };

    if (result.success) {
      // verstuur event dat deze stap voltooid is
      document.dispatchEvent(new CustomEvent('<stepName>:completed', { detail: result.detail }));
    } else {
      ui.showGlobalError(formEl, result.message || 'Er is iets misgegaan.');
      ui.hideLoader(submitBtn);
      ui.toggleFields(formEl, true);
    }
  });

  // 3d) Initialiseer knop status bij laden
  const initialValid = validateForm(schemaFields, formEl);
  ui.toggleButton(submitBtn, initialValid);
}
