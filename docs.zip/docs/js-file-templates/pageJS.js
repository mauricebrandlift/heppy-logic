/**
 * Template: <flowName>Page.js
 *
 * Orchestrator voor een multi-step form flow met benoemde stappen.
 * Gebruik in plaats van numerieke stapnummers duidelijke stapnamen.
 */

// 1) IMPORTS: init-functies per benoemde stap
import { initAddressStep } from '../forms/<flowName>/addressStepForm.js';
import { initScheduleStep } from '../forms/<flowName>/scheduleStepForm.js';
import { initDetailsStep } from '../forms/<flowName>/detailsStepForm.js';
import { initOverviewStep } from '../forms/<flowName>/overviewStepForm.js';

// 2) Paginalaad: uitsluitend de eerste stap initialiseren
document.addEventListener('DOMContentLoaded', () => {
  initAddressStep();
});

// 3) Orkestratie: luister op CustomEvents met duidelijke namen
//    Elk event wordt door de corresponderende stap-module uitgezonden

document.addEventListener('address:completed', event => {
  // event.detail bevat ingevulde adresgegevens
  initScheduleStep();
});

document.addEventListener('schedule:completed', event => {
  // event.detail bevat datum- en tijdslotkeuze
  initDetailsStep();
});

document.addEventListener('details:completed', event => {
  // event.detail bevat aanvullende informatie
  initOverviewStep();
});

// 4) Voeg hier extra listeners toe voor nieuwe benoemde stappen
//    bv. 'payment:completed', 'confirmation:completed', etc.

// ---
// Toelichting:
// - Gebruik beschrijvende event types (bijv. 'address:completed') in plaats van 'step1:completed',zodat wijzigingen in de flow volgorde geen hernummering vereisen.
// - Modules (addressStepForm.js, scheduleStepForm.js, etc.) dispatchen: document.dispatchEvent(new CustomEvent('<stepName>:completed', { detail }));
// - De page-script handelt enkel de flow-boeking af, zonder te weten hoe elke module intern werkt.
